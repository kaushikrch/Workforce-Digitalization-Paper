REPLICATION PACKAGE
===================
"When Front-Stage Innovation Overloads Back-Stage Workers"
Submitted to M&SOM

See submission/ for compiled paper (32 pp) and EC (17 pp).
See simulation/ for figure-generating code.
See empirics/ for the full data pipeline (00_run_all.sh runs core steps).
See data/ for raw and processed datasets.
