REPLICATION PACKAGE
===================
"When Front-Stage Innovation Overloads Back-Stage Workers"
Submitted to M&SOM

See submission/ for compiled paper (32 pp) and EC (16 pp).
See simulation/ for figure-generating code (outputs .pdf figures).
See empirics/ for the full data pipeline (00_run_all.sh runs core steps).
See data/ for raw and processed datasets.
