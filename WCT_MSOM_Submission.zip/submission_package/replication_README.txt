REPLICATION PACKAGE
===================
"When Front-Stage Innovation Overloads Back-Stage Workers:
 A Dynamic Model of Workforce, Capability, and Customer Trust
 in Omnichannel Retail"

Submitted to M&SOM (Manufacturing & Service Operations Management)

See submission/ for compiled paper and EC.
See simulation/ for figure-generating code.
See empirics/ for the full data pipeline (00_run_all.sh runs core steps).
See data/ for raw and processed datasets.
